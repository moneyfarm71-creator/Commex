import { z } from "zod";
import { eq, and, or, desc, asc } from "drizzle-orm";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { conversations, messages, users } from "@db/schema";

export const chatRouter = createRouter({
  // Get or create a conversation between two users
  getOrCreateConversation: authedQuery
    .input(z.object({ otherUserId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const user1Id = Math.min(ctx.user.id, input.otherUserId);
      const user2Id = Math.max(ctx.user.id, input.otherUserId);

      // Check if conversation exists
      const existing = await db
        .select()
        .from(conversations)
        .where(
          and(
            eq(conversations.user1Id, user1Id),
            eq(conversations.user2Id, user2Id)
          )
        )
        .limit(1);

      if (existing.length > 0) {
        return existing[0];
      }

      // Create new conversation
      const result = await db.insert(conversations).values({
        user1Id,
        user2Id,
      });

      return {
        id: Number(result[0].insertId),
        user1Id,
        user2Id,
        createdAt: new Date(),
      };
    }),

  // Send a message
  sendMessage: authedQuery
    .input(
      z.object({
        conversationId: z.number(),
        content: z.string().min(1).max(2000),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const result = await db.insert(messages).values({
        conversationId: input.conversationId,
        senderId: ctx.user.id,
        senderName: ctx.user.name || "Anonymous",
        content: input.content,
      });

      return {
        id: Number(result[0].insertId),
        conversationId: input.conversationId,
        senderId: ctx.user.id,
        senderName: ctx.user.name || "Anonymous",
        content: input.content,
        createdAt: new Date(),
      };
    }),

  // Get messages for a conversation
  getMessages: authedQuery
    .input(z.object({ conversationId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(messages)
        .where(eq(messages.conversationId, input.conversationId))
        .orderBy(asc(messages.createdAt));
    }),

  // Get my conversations
  getMyConversations: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const userId = ctx.user.id;

    const convs = await db
      .select()
      .from(conversations)
      .where(
        or(
          eq(conversations.user1Id, userId),
          eq(conversations.user2Id, userId)
        )
      )
      .orderBy(desc(conversations.createdAt));

    // Get other user info for each conversation
    const result = [];
    for (const conv of convs) {
      const otherUserId =
        conv.user1Id === userId ? conv.user2Id : conv.user1Id;
      const otherUser = await db
        .select()
        .from(users)
        .where(eq(users.id, otherUserId))
        .limit(1);

      // Get last message
      const lastMessage = await db
        .select()
        .from(messages)
        .where(eq(messages.conversationId, conv.id))
        .orderBy(desc(messages.createdAt))
        .limit(1);

      result.push({
        ...conv,
        otherUser: otherUser[0] || null,
        lastMessage: lastMessage[0] || null,
      });
    }

    return result;
  }),

  // Get all users (for starting new conversations)
  getAllUsers: publicQuery.query(async () => {
    const db = getDb();
    return db
      .select({
        id: users.id,
        name: users.name,
        email: users.email,
        avatar: users.avatar,
      })
      .from(users)
      .orderBy(desc(users.createdAt))
      .limit(50);
  }),

  // Poll for new messages
  pollMessages: authedQuery
    .input(
      z.object({
        conversationId: z.number(),
        lastMessageId: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      if (input.lastMessageId) {
        return db
          .select()
          .from(messages)
          .where(
            and(
              eq(messages.conversationId, input.conversationId),
              // @ts-ignore
              messages.id > input.lastMessageId
            )
          )
          .orderBy(asc(messages.createdAt));
      }
      return db
        .select()
        .from(messages)
        .where(eq(messages.conversationId, input.conversationId))
        .orderBy(asc(messages.createdAt));
    }),
});
