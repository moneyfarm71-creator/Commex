import { z } from "zod";
import { eq, desc, like, or } from "drizzle-orm";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { items } from "@db/schema";

export const itemsRouter = createRouter({
  // List all items
  list: publicQuery
    .input(
      z
        .object({
          search: z.string().optional(),
          category: z.string().optional(),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const db = getDb();

      if (input?.search) {
        const searchTerm = `%${input.search}%`;
        return db
          .select()
          .from(items)
          .where(
            or(
              like(items.title, searchTerm),
              like(items.description, searchTerm),
              like(items.location, searchTerm)
            )
          )
          .orderBy(desc(items.createdAt));
      }

      if (input?.category && input.category !== "all") {
        return db
          .select()
          .from(items)
          .where(eq(items.category, input.category))
          .orderBy(desc(items.createdAt));
      }

      return db.select().from(items).orderBy(desc(items.createdAt));
    }),

  // Get single item
  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(items)
        .where(eq(items.id, input.id))
        .limit(1);
      return result[0] || null;
    }),

  // Create item
  create: authedQuery
    .input(
      z.object({
        title: z.string().min(1).max(255),
        category: z.string().min(1),
        condition: z.string().min(1),
        location: z.string().min(1),
        description: z.string().optional(),
        image: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const result = await db.insert(items).values({
        ...input,
        donorId: ctx.user.id,
        donorName: ctx.user.name || "Anonymous",
      });

      return {
        id: Number(result[0].insertId),
        ...input,
        donorId: ctx.user.id,
        donorName: ctx.user.name || "Anonymous",
        createdAt: new Date(),
      };
    }),

  // Get categories
  getCategories: publicQuery.query(async () => {
    return [
      { value: "all", label: "All Categories" },
      { value: "furniture", label: "Furniture" },
      { value: "electronics", label: "Electronics" },
      { value: "clothing", label: "Clothing" },
      { value: "books", label: "Books" },
      { value: "home", label: "Home & Garden" },
    ];
  }),
});
