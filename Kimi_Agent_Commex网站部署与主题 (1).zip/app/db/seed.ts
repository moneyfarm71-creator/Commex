import { getDb } from "../api/queries/connection";
import { items } from "./schema";

async function seed() {
  const db = getDb();

  // Check if items already exist
  const existing = await db.select().from(items).limit(1);
  if (existing.length > 0) {
    console.log("Items already seeded, skipping...");
    return;
  }

  const sampleItems = [
    {
      title: "Wooden Study Table",
      category: "furniture",
      condition: "good",
      location: "Brooklyn, NY",
      description: "Sturdy wooden desk perfect for studying. Some minor scratches but very solid. Great for students!",
      image: "https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?w=400&h=300&fit=crop",
      donorId: 1,
      donorName: "Sarah M.",
    },
    {
      title: "Box of Colored Pencils (48 Pack)",
      category: "home",
      condition: "new",
      location: "San Francisco, CA",
      description: "Brand new set of 48 colored pencils. Never opened, perfect for art students or hobbyists.",
      image: "https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=400&h=300&fit=crop",
      donorId: 2,
      donorName: "Mike T.",
    },
    {
      title: "Vintage Dining Chairs (Set of 4)",
      category: "furniture",
      condition: "good",
      location: "Austin, TX",
      description: "Four matching wooden dining chairs. Classic design, very comfortable. Moving and can't take them.",
      image: "https://images.unsplash.com/photo-1503602642458-232111445657?w=400&h=300&fit=crop",
      donorId: 3,
      donorName: "Jake R.",
    },
    {
      title: "Children's Story Books (Box of 20)",
      category: "books",
      condition: "good",
      location: "Chicago, IL",
      description: "Collection of classic children's books. Great condition, perfect for a classroom or home library.",
      image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&h=300&fit=crop",
      donorId: 4,
      donorName: "Emma L.",
    },
    {
      title: "Garden Tools Complete Set",
      category: "home",
      condition: "good",
      location: "Seattle, WA",
      description: "Complete gardening kit with shovel, rake, trowel, and gloves. Well maintained and ready to use.",
      image: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400&h=300&fit=crop",
      donorId: 5,
      donorName: "David K.",
    },
    {
      title: "Office Chair - Ergonomic",
      category: "furniture",
      condition: "good",
      location: "Denver, CO",
      description: "Comfortable ergonomic office chair with adjustable height and lumbar support. Minor wear but fully functional.",
      image: "https://images.unsplash.com/photo-1505843490538-5133c6c7d0e1?w=400&h=300&fit=crop",
      donorId: 6,
      donorName: "Lisa P.",
    },
    {
      title: "School Supplies Bundle",
      category: "home",
      condition: "new",
      location: "Portland, OR",
      description: "Notebook, pens, pencils, erasers, ruler, and scissors. Brand new, perfect for back to school!",
      image: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=400&h=300&fit=crop",
      donorId: 7,
      donorName: "Alex S.",
    },
    {
      title: "Textbook Collection - Science & Math",
      category: "books",
      condition: "good",
      location: "Phoenix, AZ",
      description: "High school and college level textbooks. Biology, Chemistry, Algebra, and Calculus. Some notes inside.",
      image: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400&h=300&fit=crop",
      donorId: 8,
      donorName: "Roberta H.",
    },
    {
      title: "Coffee Table - Wooden",
      category: "furniture",
      condition: "good",
      location: "Miami, FL",
      description: "Beautiful oak coffee table. 36x24 inches with storage shelf underneath. Moving sale!",
      image: "https://images.unsplash.com/photo-1532372320572-cda25653a26d?w=400&h=300&fit=crop",
      donorId: 9,
      donorName: "Carlos V.",
    },
    {
      title: "Art Supplies Kit",
      category: "home",
      condition: "good",
      location: "Boston, MA",
      description: "Paints, brushes, canvas boards, and sketch pads. Great for beginners learning to paint.",
      image: "https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=400&h=300&fit=crop",
      donorId: 10,
      donorName: "Jennifer W.",
    },
    {
      title: "Bookshelf - 5 Tier",
      category: "furniture",
      condition: "good",
      location: "Atlanta, GA",
      description: "Tall wooden bookshelf with 5 shelves. Perfect for storing books, decorations, or school supplies.",
      image: "https://images.unsplash.com/photo-1594620302200-9a762244a156?w=400&h=300&fit=crop",
      donorId: 11,
      donorName: "Marcus J.",
    },
    {
      title: "Novel Collection - Fiction",
      category: "books",
      condition: "good",
      location: "Dallas, TX",
      description: "Box of 15 bestselling fiction novels. Various genres including mystery, romance, and thriller.",
      image: "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?w=400&h=300&fit=crop",
      donorId: 12,
      donorName: "Amanda K.",
    },
  ];

  for (const item of sampleItems) {
    await db.insert(items).values(item);
  }

  console.log(`Seeded ${sampleItems.length} items!`);
}

seed().catch(console.error);
