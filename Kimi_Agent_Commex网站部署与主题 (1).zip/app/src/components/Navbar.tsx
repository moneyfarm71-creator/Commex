import { Link, useLocation } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { useState } from "react";
import { LogOut, Menu, X, MessageCircle, Search, PlusCircle } from "lucide-react";

export default function Navbar() {
  const { user } = useAuth();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const logout = trpc.auth.logout.useMutation({
    onSuccess: () => {
      window.location.reload();
    },
  });

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed w-full z-50 glass border-b border-gray-200/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <img src="/logo.png" alt="Commex" className="w-10 h-10 rounded-xl mr-3 shadow-lg object-cover" />
            <span className="font-display font-bold text-2xl tracking-tight text-gray-900">
              Commex
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            <Link
              to="/browse"
              className={`flex items-center gap-2 font-medium transition-colors ${
                isActive("/browse") ? "text-brand-600" : "text-gray-600 hover:text-brand-600"
              }`}
            >
              <Search className="w-4 h-4" />
              Browse Items
            </Link>
            <Link
              to="/donate"
              className={`flex items-center gap-2 font-medium transition-colors ${
                isActive("/donate") ? "text-brand-600" : "text-gray-600 hover:text-brand-600"
              }`}
            >
              <PlusCircle className="w-4 h-4" />
              Start Donating
            </Link>
            <Link
              to="/chat"
              className={`flex items-center gap-2 font-medium transition-colors ${
                isActive("/chat") ? "text-brand-600" : "text-gray-600 hover:text-brand-600"
              }`}
            >
              <MessageCircle className="w-4 h-4" />
              Chat
            </Link>
          </div>

          {/* Auth */}
          <div className="hidden md:flex items-center space-x-4">
            {user ? (
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2 bg-white/50 px-4 py-2 rounded-full border border-gray-200">
                  <div className="w-8 h-8 bg-gradient-to-br from-brand-400 to-orange-400 rounded-full flex items-center justify-center text-white font-bold text-sm">
                    {user.name?.[0] || "U"}
                  </div>
                  <span className="font-medium text-gray-700 text-sm">
                    {user.name || "User"}
                  </span>
                </div>
                <button
                  onClick={() => logout.mutate()}
                  className="text-gray-500 hover:text-red-600 transition-colors"
                  title="Logout"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <Link
                to="/login"
                className="bg-brand-600 hover:bg-brand-700 text-white px-6 py-2 rounded-full font-medium transition-all hover:scale-105 shadow-lg shadow-brand-500/30"
              >
                Sign In
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-gray-600"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileOpen && (
          <div className="md:hidden pb-4 space-y-3 animate-fade-in">
            <Link
              to="/browse"
              onClick={() => setMobileOpen(false)}
              className="flex items-center gap-2 py-2 text-gray-600 font-medium"
            >
              <Search className="w-4 h-4" />
              Browse Items
            </Link>
            <Link
              to="/donate"
              onClick={() => setMobileOpen(false)}
              className="flex items-center gap-2 py-2 text-gray-600 font-medium"
            >
              <PlusCircle className="w-4 h-4" />
              Start Donating
            </Link>
            <Link
              to="/chat"
              onClick={() => setMobileOpen(false)}
              className="flex items-center gap-2 py-2 text-gray-600 font-medium"
            >
              <MessageCircle className="w-4 h-4" />
              Chat
            </Link>
            {user ? (
              <button
                onClick={() => { logout.mutate(); setMobileOpen(false); }}
                className="flex items-center gap-2 py-2 text-gray-600 font-medium"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </button>
            ) : (
              <Link
                to="/login"
                onClick={() => setMobileOpen(false)}
                className="inline-block bg-brand-600 text-white px-6 py-2 rounded-full font-medium"
              >
                Sign In
              </Link>
            )}
          </div>
        )}
      </div>
    </nav>
  );
}
