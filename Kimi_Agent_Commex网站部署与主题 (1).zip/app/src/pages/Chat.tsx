import { useState, useEffect, useRef } from "react";
import { useParams, Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Send, ArrowLeft, Users, Circle } from "lucide-react";

export default function Chat() {
  const { user } = useAuth();
  const { userId } = useParams();
  const [activeConv, setActiveConv] = useState<number | null>(null);
  const [messageText, setMessageText] = useState("");
  const [showUsers, setShowUsers] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Get all users to start conversations
  const { data: allUsers } = trpc.chat.getAllUsers.useQuery();

  // Get my conversations
  const { data: conversations, refetch: refetchConvos } = trpc.chat.getMyConversations.useQuery();

  // Get messages for active conversation
  const { data: msgs, refetch: refetchMsgs } = trpc.chat.getMessages.useQuery(
    { conversationId: activeConv! },
    { enabled: !!activeConv, refetchInterval: 1000 }
  );

  // tRPC mutations
  const createConv = trpc.chat.getOrCreateConversation.useMutation({
    onSuccess: (data) => {
      setActiveConv(data.id);
      refetchConvos();
      setShowUsers(false);
    },
  });

  const sendMsg = trpc.chat.sendMessage.useMutation({
    onSuccess: () => {
      refetchMsgs();
      refetchConvos();
      setMessageText("");
    },
  });

  // Auto-select conversation from URL
  useEffect(() => {
    if (userId) {
      createConv.mutate({ otherUserId: Number(userId) });
    } else if (conversations && conversations.length > 0 && !activeConv) {
      setActiveConv(conversations[0].id);
    }
  }, [userId, conversations]);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || !activeConv) return;
    sendMsg.mutate({ conversationId: activeConv, content: messageText.trim() });
  };

  const activeConvData = conversations?.find((c) => c.id === activeConv);
  const otherUser = activeConvData?.otherUser;

  return (
    <div className="min-h-screen pt-16 pb-0 bg-gray-100">
      <div className="h-[calc(100vh-4rem)] flex">
        {/* Sidebar */}
        <div className={`w-full md:w-80 bg-white border-r border-gray-200 flex flex-col ${activeConv ? "hidden md:flex" : "flex"}`}>
          <div className="p-4 border-b border-gray-200 flex items-center justify-between">
            <div>
              <h2 className="font-display text-xl font-bold text-gray-900">Messages</h2>
              <p className="text-sm text-gray-500 mt-1">Chat with members</p>
            </div>
            <button
              onClick={() => setShowUsers(!showUsers)}
              className="p-2 bg-brand-100 text-brand-600 rounded-lg hover:bg-brand-200 transition-colors"
              title="Start new conversation"
            >
              <Users className="w-5 h-5" />
            </button>
          </div>

          {/* New conversation users list */}
          {showUsers && (
            <div className="p-3 border-b border-gray-200 bg-gray-50 max-h-60 overflow-y-auto">
              <p className="text-xs font-semibold text-gray-500 uppercase mb-2">Start chatting with</p>
              {allUsers?.filter((u) => u.id !== user?.id).map((u) => (
                <button
                  key={u.id}
                  onClick={() => createConv.mutate({ otherUserId: u.id })}
                  className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-white transition-colors text-left"
                >
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-brand-400 to-orange-400 flex items-center justify-center text-white font-bold text-sm">
                    {u.name?.[0] || "U"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 text-sm truncate">{u.name || "Anonymous"}</p>
                  </div>
                </button>
              ))}
              {(!allUsers || allUsers.length <= 1) && (
                <p className="text-sm text-gray-400 py-2">No other users yet. Invite friends!</p>
              )}
            </div>
          )}

          {/* Conversations list */}
          <div className="flex-1 overflow-y-auto">
            {conversations?.map((conv) => {
              const isActive = conv.id === activeConv;
              return (
                <button
                  key={conv.id}
                  onClick={() => setActiveConv(conv.id)}
                  className={`w-full p-4 border-b border-gray-100 hover:bg-gray-50 transition-colors text-left ${
                    isActive ? "bg-brand-50 border-l-4 border-l-brand-500" : ""
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="relative flex-shrink-0">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-brand-400 to-orange-400 flex items-center justify-center text-white font-bold text-lg">
                        {conv.otherUser?.name?.[0] || "U"}
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-center mb-1">
                        <h3 className="font-semibold text-gray-900 truncate">
                          {conv.otherUser?.name || "Anonymous"}
                        </h3>
                        {conv.lastMessage && (
                          <span className="text-xs text-gray-400 flex-shrink-0 ml-2">
                            {new Date(conv.lastMessage.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-500 truncate">
                        {conv.lastMessage?.content || "No messages yet"}
                      </p>
                    </div>
                  </div>
                </button>
              );
            })}

            {(!conversations || conversations.length === 0) && (
              <div className="p-8 text-center">
                <p className="text-gray-500 mb-4">No conversations yet</p>
                <button
                  onClick={() => setShowUsers(true)}
                  className="text-brand-600 font-medium hover:text-brand-700"
                >
                  Start a new conversation
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Chat Area */}
        <div className={`flex-1 flex flex-col bg-gray-50 ${!activeConv ? "hidden md:flex" : ""}`}>
          {activeConv && otherUser ? (
            <>
              {/* Header */}
              <div className="bg-white border-b border-gray-200 px-4 md:px-6 py-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setActiveConv(null)}
                    className="md:hidden p-2 -ml-2 text-gray-500"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </button>
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-brand-400 to-orange-400 flex items-center justify-center text-white font-bold">
                    {otherUser.name?.[0] || "U"}
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900">{otherUser.name || "Anonymous"}</h3>
                    <p className="text-sm text-green-600 flex items-center gap-1">
                      <Circle className="w-2 h-2 fill-current" />
                      Online
                    </p>
                  </div>
                </div>
                <Link to="/browse" className="text-sm text-brand-600 font-medium hover:text-brand-700">
                  Browse Items &rarr;
                </Link>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
                {msgs?.map((msg) => {
                  const isSent = msg.senderId === user?.id;
                  return (
                    <div
                      key={msg.id}
                      className={`max-w-[80%] p-3 rounded-2xl ${
                        isSent
                          ? "chat-bubble-sent ml-auto"
                          : "chat-bubble-received"
                      } animate-fade-in`}
                    >
                      {!isSent && (
                        <div className="text-xs opacity-75 mb-1 font-semibold">{msg.senderName}</div>
                      )}
                      <div>{msg.content}</div>
                      <div className={`text-xs mt-1 text-right ${isSent ? "text-orange-100" : "text-gray-400"}`}>
                        {new Date(msg.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>

              {/* Input */}
              <div className="bg-white border-t border-gray-200 p-4">
                <form onSubmit={handleSend} className="flex gap-3">
                  <input
                    type="text"
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    placeholder="Type a message..."
                    className="flex-1 px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none"
                    autoComplete="off"
                  />
                  <button
                    type="submit"
                    disabled={!messageText.trim() || sendMsg.isPending}
                    className="bg-brand-600 hover:bg-brand-700 disabled:opacity-50 disabled:cursor-not-allowed text-white px-6 py-3 rounded-xl font-medium transition-colors flex items-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span className="hidden sm:inline">Send</span>
                  </button>
                </form>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-gray-400 p-8">
              <div className="w-20 h-20 bg-brand-100 rounded-full flex items-center justify-center mb-4">
                <Users className="w-10 h-10 text-brand-400" />
              </div>
              <p className="text-lg font-medium text-gray-500 mb-2">Select a conversation</p>
              <p className="text-sm text-center mb-6">Choose someone from the sidebar or start a new chat</p>
              <button
                onClick={() => setShowUsers(true)}
                className="bg-brand-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-brand-700 transition-colors"
              >
                Start New Chat
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
