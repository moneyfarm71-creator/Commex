import { Link } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { Search, PlusCircle, MessageCircle, Package, Truck } from "lucide-react";

export default function Home() {
  const { user } = useAuth();

  return (
    <div className="pt-16">
      {/* Hero */}
      <div className="relative overflow-hidden min-h-screen flex items-center">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-100 via-amber-50 to-orange-50" />
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-10 left-[10%] w-96 h-96 bg-gradient-to-br from-orange-300/40 to-amber-300/40 rounded-full mix-blend-multiply filter blur-3xl animate-float" />
          <div className="absolute top-[30%] right-[5%] w-80 h-80 bg-gradient-to-br from-amber-300/40 to-yellow-300/40 rounded-full mix-blend-multiply filter blur-3xl animate-float" style={{ animationDelay: "2s" }} />
          <div className="absolute bottom-[10%] left-[30%] w-72 h-72 bg-gradient-to-br from-orange-400/30 to-red-300/30 rounded-full mix-blend-multiply filter blur-3xl animate-float" style={{ animationDelay: "4s" }} />
          <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, #ea580c 1px, transparent 0)", backgroundSize: "40px 40px" }} />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center max-w-4xl mx-auto">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-white/80 backdrop-blur-sm border border-brand-200 text-brand-700 text-sm font-semibold mb-10 shadow-lg shadow-brand-100/50">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-brand-500" />
              </span>
              Community-Powered Exchange
            </div>

            {/* Heading */}
            <h1 className="font-display text-6xl md:text-8xl font-bold text-gray-900 leading-[1.1] mb-8 tracking-tight">
              Give. <span className="text-brand-600">Connect.</span>
              <br />
              <span className="relative inline-block">
                <span className="gradient-text">Deliver.</span>
                <svg className="absolute -bottom-2 left-0 w-full h-4 text-brand-300" viewBox="0 0 200 12" fill="none" preserveAspectRatio="none">
                  <path d="M2 10C50 2 150 2 198 10" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
                </svg>
              </span>
            </h1>

            <p className="text-xl md:text-2xl text-gray-600 mb-12 leading-relaxed max-w-2xl mx-auto">
              Join thousands of community members donating items and connecting through chat.
              You arrange the delivery, we facilitate the connection.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-5 justify-center items-center">
              <Link
                to="/browse"
                className="group relative bg-brand-600 hover:bg-brand-700 text-white px-10 py-5 rounded-2xl font-bold text-lg transition-all hover:scale-105 shadow-2xl shadow-brand-500/40 flex items-center justify-center gap-3 overflow-hidden"
              >
                <Search className="w-6 h-6" />
                Browse Items
              </Link>
              <Link
                to={user ? "/donate" : "/login"}
                className="group bg-white hover:bg-gray-50 text-gray-900 border-2 border-gray-200 hover:border-brand-300 px-10 py-5 rounded-2xl font-bold text-lg transition-all hover:scale-105 flex items-center justify-center gap-3 shadow-lg"
              >
                <div className="w-10 h-10 bg-brand-100 rounded-xl flex items-center justify-center group-hover:bg-brand-200 transition-colors">
                  <PlusCircle className="w-5 h-5 text-brand-600" />
                </div>
                Start Donating
              </Link>
            </div>

            {/* Stats */}
            <div className="mt-16 flex flex-wrap justify-center gap-8 md:gap-16">
              <div className="text-center">
                <div className="text-4xl font-bold text-brand-600 mb-1">2,500+</div>
                <div className="text-gray-500 text-sm">Items Donated</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-brand-600 mb-1">1,200+</div>
                <div className="text-gray-500 text-sm">Happy Members</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-brand-600 mb-1">$5</div>
                <div className="text-gray-500 text-sm">Flat Fee</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-12">
            <div className="group p-8 rounded-3xl bg-gray-50 hover:bg-brand-50 transition-all duration-300 border border-transparent hover:border-brand-200">
              <div className="w-14 h-14 bg-brand-100 rounded-2xl flex items-center justify-center text-brand-600 mb-6 group-hover:scale-110 transition-transform">
                <Package className="w-7 h-7" />
              </div>
              <h3 className="font-display text-xl font-bold mb-3">List Items</h3>
              <p className="text-gray-600">Post items you want to donate. From furniture to books, supplies to garden tools. Everything finds a home.</p>
            </div>
            <div className="group p-8 rounded-3xl bg-gray-50 hover:bg-orange-50 transition-all duration-300 border border-transparent hover:border-orange-200">
              <div className="w-14 h-14 bg-orange-100 rounded-2xl flex items-center justify-center text-orange-600 mb-6 group-hover:scale-110 transition-transform">
                <MessageCircle className="w-7 h-7" />
              </div>
              <h3 className="font-display text-xl font-bold mb-3">Chat & Connect</h3>
              <p className="text-gray-600">Message other members directly in real-time. Coordinate pickup times, ask questions, and build connections.</p>
            </div>
            <div className="group p-8 rounded-3xl bg-gray-50 hover:bg-amber-50 transition-all duration-300 border border-transparent hover:border-amber-200">
              <div className="w-14 h-14 bg-amber-100 rounded-2xl flex items-center justify-center text-amber-600 mb-6 group-hover:scale-110 transition-transform">
                <Truck className="w-7 h-7" />
              </div>
              <h3 className="font-display text-xl font-bold mb-3">Arrange Delivery</h3>
              <p className="text-gray-600">You handle the pickup or delivery. Meet safely in public places or arrange doorstep drop-offs.</p>
            </div>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="py-24 bg-gray-900 text-white relative overflow-hidden">
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl font-bold mb-4">Simple & Transparent</h2>
            <p className="text-gray-400 text-lg">$5 flat fee per receiving transaction. No hidden costs.</p>
          </div>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { step: "1", title: "Browse", desc: "Find items you need in your community" },
              { step: "2", title: "Connect", desc: "Chat with the donor to arrange details" },
              { step: "3", title: "Pay $5", desc: "Small fee to support the platform" },
              { step: "4", title: "Receive", desc: "Pick up your items and enjoy!" },
            ].map((s) => (
              <div key={s.step} className="text-center">
                <div className="w-16 h-16 rounded-full bg-brand-500 flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                  {s.step}
                </div>
                <h4 className="font-bold text-lg mb-2">{s.title}</h4>
                <p className="text-gray-400 text-sm">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
